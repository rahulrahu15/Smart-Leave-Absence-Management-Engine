import boto3
import os
import json
from datetime import datetime

dynamodb = boto3.resource('dynamodb')

LEAVE_REQUESTS_TABLE = os.environ.get('LEAVE_REQUESTS_TABLE', 'lms-leave-requests-dev')
LEAVE_BALANCES_TABLE = os.environ.get('LEAVE_BALANCES_TABLE', 'lms-leave-balances-dev')

requests_table = dynamodb.Table(LEAVE_REQUESTS_TABLE)
balances_table = dynamodb.Table(LEAVE_BALANCES_TABLE)


def get_roles(event):
    claims = event["requestContext"]["authorizer"]["claims"]
    groups = claims.get("cognito:groups", "")

    if isinstance(groups, str):
        return groups.split(",")
    return groups or []


def date_range(start, end):
    start_date = datetime.strptime(start, "%Y-%m-%d")
    end_date = datetime.strptime(end, "%Y-%m-%d")
    return (end_date - start_date).days + 1


def lambda_handler(event, context):

    roles = get_roles(event)

    if "MANAGER" not in roles and "HR" not in roles:
        return {
            "statusCode": 403,
            "body": json.dumps({"message": "Access denied"})
        }

    params = event.get('queryStringParameters', {})

    employee_id = params['employee_id']
    request_id = params['request_id']

    res = requests_table.get_item(
        Key={"employee_id": employee_id, "request_id": request_id}
    )

    if 'Item' not in res:
        return {
            "statusCode": 404,
            "body": json.dumps({"message": "Request not found"})
        }

    item = res['Item']

    # ---------------------------------------
    # ROLE-BASED APPROVAL LOGIC (FIX)
    # ---------------------------------------

    leave_type = item['leave_type']
    days = date_range(item['start_date'], item['end_date'])

    # 🔥 MANAGER APPROVAL
    if "MANAGER" in roles:

        if item.get("manager_status") == "MANAGER_APPROVED":
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Already approved by manager"})
            }

        requests_table.update_item(
            Key={"employee_id": employee_id, "request_id": request_id},
            UpdateExpression="""
                SET manager_status = :m,
                    #s = :status,
                    hr_status = if_not_exists(hr_status, :hr)
            """,
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={
                ":m": "MANAGER_APPROVED",
                ":status": "MANAGER_APPROVED",
                ":hr": "PENDING"
            }
        )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Manager approved successfully",
                "request_id": request_id,
                "status": "MANAGER_APPROVED"
            })
        }

    # 🔥 HR APPROVAL (FINAL)
    if "HR" in roles:

        if item.get("status") != "MANAGER_APPROVED":
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "message": "Cannot approve before manager approval"
                })
            }

        # Deduct balance ONLY at final stage
        balances_table.update_item(
            Key={'employee_id': employee_id},
            UpdateExpression=f"SET {leave_type} = {leave_type} - :d",
            ExpressionAttributeValues={':d': days}
        )

        requests_table.update_item(
            Key={"employee_id": employee_id, "request_id": request_id},
            UpdateExpression="""
                SET hr_status = :h,
                    #s = :status
            """,
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={
                ":h": "APPROVED",
                ":status": "APPROVED"
            }
        )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "HR approved successfully",
                "request_id": request_id,
                "status": "APPROVED"
            })
        }