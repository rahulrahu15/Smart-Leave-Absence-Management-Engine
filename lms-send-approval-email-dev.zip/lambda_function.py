import boto3
import json
import base64
import hmac
import hashlib
import time
import os

ses = boto3.client('ses')

# Environment variables
SECRET = os.environ['TOKEN_SECRET']
API_URL = os.environ['API_URL']
FROM_EMAIL = os.environ['FROM_EMAIL']


# -----------------------------
# TOKEN GENERATION
# -----------------------------
def generate_token(data):
    payload = json.dumps(data, separators=(',', ':')).encode()
    b64 = base64.urlsafe_b64encode(payload).decode()

    signature = hmac.new(
        SECRET.encode(),
        b64.encode(),
        hashlib.sha256
    ).hexdigest()

    return f"{b64}.{signature}"


# -----------------------------
# MAIN HANDLER
# -----------------------------
def lambda_handler(event, context):
    print("EVENT:", event)

    employee_id = event["employee_id"]
    request_id = event["request_id"]

    # -----------------------------
    # TOKEN PAYLOAD
    # -----------------------------
    token_data = {
        "employee_id": employee_id,
        "request_id": request_id,
        "role": "manager",
        "expiry": int(time.time()) + 3600  # 1 hour validity
    }

    token = generate_token(token_data)

    # -----------------------------
    # APPROVAL LINKS
    # -----------------------------
    base_url = API_URL.rstrip("/")  # prevents double slashes

    approve_link = f"{API_URL}/leave/approve?token={token}"
    reject_link = f"{API_URL}/leave/reject?token={token}"

    # -----------------------------
    # EMAIL CONTENT
    # -----------------------------
    subject = "Leave Approval Required"

    body_text = f"""
You have a new leave request.

Employee ID: {employee_id}
Request ID: {request_id}

Approve:
{approve_link}

Reject:
{reject_link}

This link will expire in 1 hour.
"""

    # -----------------------------
    # SEND EMAIL
    # -----------------------------
    try:
        response = ses.send_email(
            Source=FROM_EMAIL,
            Destination={
                "ToAddresses": ["rahulmenon4475@gmail.com"]
            },
            Message={
                "Subject": {"Data": subject},
                "Body": {
                    "Text": {"Data": body_text}
                }
            }
        )

        print("SES RESPONSE:", response)

    except Exception as e:
        print("EMAIL ERROR:", str(e))
        raise e

    # -----------------------------
    # RETURN EVENT TO STEP FUNCTION
    # -----------------------------
    return {
        **event,
        "email_sent": True,
        "approval_link_generated": True
    }