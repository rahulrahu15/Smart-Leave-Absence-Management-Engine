import boto3
import os
import json
import time
import base64
import hmac
import hashlib

lambda_client = boto3.client("lambda")

dynamodb = boto3.resource("dynamodb")
requests_table = dynamodb.Table("lms-leave-requests-dev")  # ✅ ADDED

SECRET = os.environ["TOKEN_SECRET"]
API_URL = os.environ["API_URL"].rstrip("/")

NOTIFICATION_LAMBDA = "lms-notification-service-dev"


def generate_token(data):
    payload = json.dumps(data, separators=(',', ':')).encode()
    b64 = base64.urlsafe_b64encode(payload).decode()

    signature = hmac.new(
        SECRET.encode(),
        b64.encode(),
        hashlib.sha256
    ).hexdigest()

    return f"{b64}.{signature}"


def notify(payload):
    lambda_client.invoke(
        FunctionName=NOTIFICATION_LAMBDA,
        InvocationType="Event",
        Payload=json.dumps(payload)
    )


def lambda_handler(event, context):

    print("HR EMAIL EVENT:", json.dumps(event))

    # -----------------------------
    # SAFETY CHECK
    # -----------------------------
    required_fields = ["employee_id", "request_id"]

    for f in required_fields:
        if f not in event:
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Invalid event payload"})
            }

    employee_id = event["employee_id"]
    request_id = event["request_id"]

    employee_name = event.get("employee_name", "Employee")
    leave_type = event.get("leave_type", "")
    start_date = event.get("start_date", "")
    end_date = event.get("end_date", "")
    leave_days = event.get("leave_days", 0)

    # -----------------------------
    # ✅ UPDATE DB → SET HR PENDING
    # -----------------------------
    try:
        requests_table.update_item(
            Key={
                "employee_id": employee_id,
                "request_id": request_id
            },
            UpdateExpression="SET hr_status = :s",
            ExpressionAttributeValues={
                ":s": "PENDING"
            }
        )
        print("HR status set to PENDING")
    except Exception as e:
        print("Error updating HR status:", str(e))

    # -----------------------------
    # TOKEN GENERATION
    # -----------------------------
    token_data = {
        "employee_id": employee_id,
        "request_id": request_id,
        "role": "hr",
        "issued_at": int(time.time()),
        "expiry": int(time.time()) + 3600
    }

    token = generate_token(token_data)

    approve_link = f"{API_URL}/leave/approve?token={token}"
    reject_link = f"{API_URL}/leave/reject?token={token}"

    # -----------------------------
    # NOTIFY HR
    # -----------------------------
    notify({
        "type": "HR_PENDING",
        "employee_id": employee_id,
        "employee_name": employee_name,
        "request_id": request_id,
        "leave_type": leave_type,
        "start_date": start_date,
        "end_date": end_date,
        "leave_days": leave_days,
        "status": "HR_PENDING",
        "message": "HR approval required",
        "approve_link": approve_link,
        "reject_link": reject_link
    })

    return {
        "statusCode": 200,
        "body": json.dumps({
            "employee_id": employee_id,
            "request_id": request_id,
            "status": "HR_PENDING"
        })
    }