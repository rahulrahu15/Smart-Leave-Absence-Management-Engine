import json
import boto3
import uuid
import os
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')
stepfunctions = boto3.client('stepfunctions')

LEAVE_REQUESTS_TABLE = os.environ['LEAVE_REQUESTS_TABLE']
LEAVE_BALANCES_TABLE = os.environ['LEAVE_BALANCES_TABLE']
LEAVE_CONFIG_TABLE = os.environ['LEAVE_CONFIG_TABLE']
SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN']
STATE_MACHINE_ARN = os.environ['STATE_MACHINE_ARN']

leave_requests_table = dynamodb.Table(LEAVE_REQUESTS_TABLE)
leave_balances_table = dynamodb.Table(LEAVE_BALANCES_TABLE)
leave_config_table = dynamodb.Table(LEAVE_CONFIG_TABLE)


def parse_body(event):
    if "body" in event:
        if isinstance(event["body"], str):
            return json.loads(event["body"])
        return event["body"]
    return event


def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except:
        return datetime.strptime(date_str, "%d-%m-%Y")


def date_range(start, end):
    start_date = parse_date(start)
    end_date = parse_date(end)

    return [
        (start_date + timedelta(days=i)).strftime("%Y-%m-%d")
        for i in range((end_date - start_date).days + 1)
    ]


def lambda_handler(event, context):

    body = parse_body(event)

    authorizer = event.get("requestContext", {}).get("authorizer", {})
    claims = authorizer.get("jwt", {}).get("claims", {})

    employee_id = claims.get("sub")
    employee_name = claims.get("name", "Unknown")

    employee_email = claims.get("email")

    if not employee_id:
        return {
            "statusCode": 401,
            "body": json.dumps({"error": "Unauthorized - missing JWT claims"})
        }

    leave_type = body["leave_type"]
    start_date = body["start_date"]
    end_date = body["end_date"]

    # ✅ 🔥 FIX ADDED HERE: capture reason from frontend request
    reason = body.get("reason")   # <-- THIS WAS MISSING EARLIER

    try:
        start = parse_date(start_date)
        end = parse_date(end_date)

        if end < start:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "End date cannot be before start date"})
            }

    except Exception:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Invalid date format"})
        }

    request_id = str(uuid.uuid4())
    requested_days = len(date_range(start_date, end_date))

    balance_res = leave_balances_table.get_item(
        Key={"employee_id": employee_id}
    )

    if "Item" not in balance_res:
        config = leave_config_table.scan().get("Items", [])

        balance_item = {"employee_id": employee_id}

        for c in config:
            balance_item[c["leave_type"]] = c["annual_quota"]

        leave_balances_table.put_item(Item=balance_item)
        balance_res = {"Item": balance_item}

    available_balance = balance_res["Item"].get(leave_type, 0)

    existing = leave_requests_table.query(
        KeyConditionExpression=Key("employee_id").eq(employee_id)
    )["Items"]

    new_dates = set(date_range(start_date, end_date))

    overlap = False
    for item in existing:
        if item.get("status") == "APPROVED":
            old_dates = set(date_range(item["start_date"], item["end_date"]))
            if new_dates.intersection(old_dates):
                overlap = True
                break

    status = "PENDING"

    # -----------------------------
    # FIXED REASON HANDLING
    # -----------------------------
    if not reason:
        reason = None   # keep system behavior safe if user doesn't enter

    if requested_days > available_balance:
        status = "REJECTED"
        reason = reason or "Insufficient leave balance"

    elif overlap:
        status = "REJECTED"
        reason = reason or "Overlapping approved leave exists"

    item = {
        "employee_id": employee_id,
        "employee_name": employee_name,
        "employee_email": employee_email,
        "leave_days": requested_days,
        "request_id": request_id,
        "leave_type": leave_type,
        "start_date": start_date,
        "end_date": end_date,
        "status": status,
        "reason": reason,   # ✅ NOW PROPERLY STORED
        "created_at": datetime.utcnow().isoformat()
    }

    leave_requests_table.put_item(Item=item)

    if status == "REJECTED":
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps({
                "employee_id": employee_id,
                "employee_name": employee_name,
                "request_id": request_id,
                "status": "REJECTED",
                "reason": reason
            }),
            Subject="Leave Rejected"
        )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "status": "REJECTED",
                "reason": reason,
                "request_id": request_id
            })
        }

    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message=json.dumps({
            "employee_id": employee_id,
            "employee_name": employee_name,
            "request_id": request_id,
            "status": "PENDING"
        }),
        Subject="Leave Request Submitted"
    )

    stepfunctions.start_execution(
        stateMachineArn=STATE_MACHINE_ARN,
        input=json.dumps({
            "employee_id": employee_id,
            "employee_name": employee_name,
            "employee_email": employee_email,
            "request_id": request_id,
            "leave_type": leave_type,
            "leave_days": requested_days
        })
    )

    return {
        "statusCode": 200,
        "body": json.dumps({
            "status": "PENDING",
            "message": "Leave submitted",
            "request_id": request_id
        })
    }