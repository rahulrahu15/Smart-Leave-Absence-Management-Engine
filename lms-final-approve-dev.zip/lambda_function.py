import boto3
import os
from datetime import datetime
import json

dynamodb = boto3.resource('dynamodb')
lambda_client = boto3.client("lambda")

requests_table = dynamodb.Table(os.environ['LEAVE_REQUESTS_TABLE'])
balances_table = dynamodb.Table(os.environ['LEAVE_BALANCES_TABLE'])

NOTIFICATION_LAMBDA = "lms-notify-employee-dev"


# -----------------------------
# NOTIFY HELPER
# -----------------------------
def notify(payload):
    lambda_client.invoke(
        FunctionName=NOTIFICATION_LAMBDA,
        InvocationType="Event",
        Payload=json.dumps(payload)
    )


def lambda_handler(event, context):

    # ---------------------------------
    # 🔐 SAFETY CHECK (NON-BREAKING)
    # ---------------------------------
    if "employee_id" not in event or "request_id" not in event:
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Invalid input"})
        }

    employee_id = event["employee_id"]
    request_id = event["request_id"]

    # ---------------------------------
    # FETCH REQUEST
    # ---------------------------------
    res = requests_table.get_item(
        Key={"employee_id": employee_id, "request_id": request_id}
    )

    if "Item" not in res:
        return {
            "statusCode": 404,
            "body": json.dumps({"message": "Request not found"})
        }

    item = res["Item"]

    leave_type = item["leave_type"]
    start = item["start_date"]
    end = item["end_date"]
    employee_name = item.get("employee_name", "Unknown")

    days = (datetime.strptime(end, "%Y-%m-%d") -
            datetime.strptime(start, "%Y-%m-%d")).days + 1

    # ---------------------------------
    # DEDUCT BALANCE
    # ---------------------------------
    balances_table.update_item(
        Key={"employee_id": employee_id},
        UpdateExpression=f"SET {leave_type} = {leave_type} - :d",
        ExpressionAttributeValues={":d": days}
    )

    # ---------------------------------
    # UPDATE STATUS
    # ---------------------------------
    requests_table.update_item(
        Key={"employee_id": employee_id, "request_id": request_id},
        UpdateExpression="SET #s = :s",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":s": "APPROVED"}
    )

    # ---------------------------------
    # NOTIFY EMPLOYEE
    # ---------------------------------
    notify({
        "employee_id": employee_id,
        "employee_name": employee_name,
        "request_id": request_id,
        "leave_type": leave_type,
        "leave_days": days,
        "start_date": start,
        "end_date": end,
        "status": "APPROVED"
    })

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Final approval completed",
            "request_id": request_id,
            "status": "APPROVED"
        })
    }