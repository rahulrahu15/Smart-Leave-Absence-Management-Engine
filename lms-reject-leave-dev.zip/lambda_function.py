import boto3
import json

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('lms-leave-requests-dev')


# -----------------------------
# ROLE CHECK (RBAC)
# -----------------------------
def get_roles(event):
    claims = event["requestContext"]["authorizer"]["claims"]
    groups = claims.get("cognito:groups", "")

    if isinstance(groups, str):
        return groups.split(",")
    return groups or []


def lambda_handler(event, context):

    # -----------------------------
    # 🔐 RBAC CHECK
    # -----------------------------
    roles = get_roles(event)

    if "MANAGER" not in roles and "HR" not in roles:
        return {
            "statusCode": 403,
            "body": json.dumps({"message": "Access denied"})
        }

    # -----------------------------
    # INPUT (still required for target request)
    # -----------------------------
    params = event.get('queryStringParameters', {})

    employee_id = params['employee_id']
    request_id = params['request_id']

    # ---------------------------------------
    # UPDATE REQUEST STATUS
    # ---------------------------------------
    table.update_item(
        Key={"employee_id": employee_id, "request_id": request_id},
        UpdateExpression="SET #s = :val",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":val": "REJECTED"}
    )

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Rejected successfully",
            "request_id": request_id,
            "status": "REJECTED"
        })
    }