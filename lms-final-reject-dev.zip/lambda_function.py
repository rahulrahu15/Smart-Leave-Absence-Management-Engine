import boto3
import os
import json

dynamodb = boto3.resource('dynamodb')
ses = boto3.client('ses')

table = dynamodb.Table(os.environ['LEAVE_REQUESTS_TABLE'])

FROM_EMAIL = os.environ['FROM_EMAIL']


def send_email(to_email, subject, body):
    ses.send_email(
        Source=FROM_EMAIL,
        Destination={"ToAddresses": [to_email]},
        Message={
            "Subject": {"Data": subject},
            "Body": {"Text": {"Data": body}}
        }
    )


def lambda_handler(event, context):

    print("EVENT:", json.dumps(event))

    # -----------------------------
    # INPUT VALIDATION
    # -----------------------------
    if "employee_id" not in event or "request_id" not in event:
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Invalid input"})
        }

    employee_id = event["employee_id"]
    request_id = event["request_id"]

    # -----------------------------
    # FIXED REASON LOGIC (ONLY CHANGE)
    # -----------------------------
    if "reason" in event:
        reason = event["reason"]
    else:
        if event.get("hr_rejected"):
            reason = "Rejected by HR"
        elif event.get("manager_rejected"):
            reason = "Rejected by manager"
        else:
            reason = "Rejected"

    # -----------------------------
    # FETCH REQUEST
    # -----------------------------
    response = table.get_item(
        Key={
            "employee_id": employee_id,
            "request_id": request_id
        }
    )

    item = response.get("Item")

    if not item:
        return {
            "statusCode": 404,
            "body": json.dumps({"message": "Request not found"})
        }

    employee_name = item.get("employee_name", "Employee")
    leave_type = item.get("leave_type", "N/A")
    start_date = item.get("start_date", "N/A")
    end_date = item.get("end_date", "N/A")

    # -----------------------------
    # SAFE EMAIL RESOLUTION
    # -----------------------------
    employee_email = item.get("email") or item.get("employee_email")

    if not employee_email:
        print("⚠️ Email missing in DB, fallback to skipping SES")
        employee_email = None

    # -----------------------------
    # UPDATE STATUS
    # -----------------------------
    table.update_item(
        Key={
            "employee_id": employee_id,
            "request_id": request_id
        },
        UpdateExpression="SET #s = :s, hr_status = :h, reason = :r",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={
            ":s": "REJECTED",
            ":h": "REJECTED",
            ":r": reason
        }
    )

    # -----------------------------
    # EMAIL
    # -----------------------------
    if employee_email:
        send_email(
            to_email=employee_email,
            subject="Leave Request Rejected",
            body=f"""
Hello {employee_name},

Your leave request has been REJECTED.

Request ID: {request_id}
Leave Type: {leave_type}
Dates: {start_date} to {end_date}

Reason: {reason}

Regards,
Smart Leave System
"""
        )
    else:
        print("❌ Email not sent because employee_email is missing")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "employee_id": employee_id,
            "request_id": request_id,
            "status": "REJECTED"
        })
    }