import json
import boto3
import os

ses = boto3.client("ses")

# -----------------------------
# ENV VARIABLES
# -----------------------------
FROM_EMAIL = os.environ["FROM_EMAIL"]


# -----------------------------
# MAIN HANDLER
# -----------------------------
def lambda_handler(event, context):

    print("NOTIFICATION EVENT:", json.dumps(event))

    event_type = event.get("type") or event.get("status")

    employee_id = event.get("employee_id", "Unknown")
    employee_name = event.get("employee_name", "Employee")
    request_id = event.get("request_id", "N/A")

    # -----------------------------
    # HR PENDING EMAIL
    # -----------------------------
    if event_type == "HR_PENDING":

        subject = "HR Approval Required"

        body = f"""
Hello HR,

A leave request requires your approval.

Employee: {employee_name}
Employee ID: {employee_id}
Request ID: {request_id}

Approve Link:
{event.get('approve_link')}

Reject Link:
{event.get('reject_link')}

Regards,
Smart Leave System
"""

    # -----------------------------
    # SUBMITTED / PENDING
    # -----------------------------
    elif event_type in ["SUBMITTED", "PENDING"]:

        subject = "Leave Request Submitted"

        body = f"""
Hello {employee_name},

Your leave request has been submitted and is currently pending approval.

Request ID: {request_id}

Regards,
Smart Leave System
"""

    # -----------------------------
    # APPROVED
    # -----------------------------
    elif event_type == "APPROVED":

        subject = "Leave Approved"

        body = f"""
Hello {employee_name},

Your leave request has been APPROVED.

Request ID: {request_id}

Enjoy your leave!

Regards,
Smart Leave System
"""

    # -----------------------------
    # REJECTED
    # -----------------------------
    elif event_type == "REJECTED":

        reason = event.get("reason", "No reason provided")

        subject = "Leave Rejected"

        body = f"""
Hello {employee_name},

Your leave request has been REJECTED.

Request ID: {request_id}

Reason: {reason}

Please contact HR if needed.

Regards,
Smart Leave System
"""

    # -----------------------------
    # UNKNOWN EVENT (SAFETY)
    # -----------------------------
    else:
        print("Unknown event type:", event_type)
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Unknown event type"})
        }

    # -----------------------------
    # SEND EMAIL
    # -----------------------------
    try:
        ses.send_email(
            Source=FROM_EMAIL,
            Destination={
                "ToAddresses": [FROM_EMAIL]
            },
            Message={
                "Subject": {"Data": subject},
                "Body": {"Text": {"Data": body}}
            }
        )

        print("EMAIL SENT SUCCESSFULLY")

    except Exception as e:
        print("SES ERROR:", str(e))
        raise e

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Notification sent",
            "type": event_type,
            "request_id": request_id
        })
    }