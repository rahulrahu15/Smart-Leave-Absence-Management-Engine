import json
import boto3
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')

LEAVE_BALANCES_TABLE = os.environ.get('LEAVE_BALANCES_TABLE', 'lms-leave-balances-dev')

table = dynamodb.Table(LEAVE_BALANCES_TABLE)


def convert_decimals(obj):
    if isinstance(obj, list):
        return [convert_decimals(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimals(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        return int(obj)
    else:
        return obj


def lambda_handler(event, context):

    print("EVENT:", event)

    # 🔐 GET USER FROM COGNITO TOKEN
    claims = event["requestContext"]["authorizer"]["claims"]
    employee_id = claims["sub"]

    res = table.get_item(Key={'employee_id': employee_id})

    if 'Item' not in res:
        return {
            "statusCode": 404,
            "body": json.dumps({"message": "No balance found"})
        }

    clean_data = convert_decimals(res['Item'])

    return {
        "statusCode": 200,
        "body": json.dumps(clean_data)
    }