import boto3
import json
import os

ses = boto3.client("ses")

dynamodb = boto3.resource("dynamodb")
balances_table = dynamodb.Table("lms-leave-balances-dev")
requests_table = dynamodb.Table("lms-leave-requests-dev")  

FROM_EMAIL = os.environ["FROM_EMAIL"]


def lambda_handler(event, context):

    print("NOTIFY EMPLOYEE EVENT:", json.dumps(event))

    employee_name = event.get("employee_name", "Employee")
    request_id = event.get("request_id", "N/A")
    status = event.get("status", "UPDATED")
    employee_id = event.get("employee_id")

    subject = f"Leave {status}"

    # 🔥 FIXED EMPLOYEE EMAIL LOGIC
    employee_email = (
        event.get("employee_email")
        or event.get("email")
        or event.get("user_email")
    )

    if not employee_email and employee_id and request_id:
        try:
            res = requests_table.get_item(
                Key={
                    "employee_id": employee_id,
                    "request_id": request_id
                }
            )
            item = res.get("Item", {})

            employee_email = (
                item.get("employee_email")
                or item.get("email")
            )

            print("Fetched email from DB:", employee_email)

        except Exception as e:
            print("Email fetch error:", str(e))

    if not employee_email:
        print(f"WARNING: Email missing for {employee_id}, skipping email send")
        return {
            "statusCode": 200,
            "message": "Email skipped due to missing address"
        }

    # ---------------- APPROVED FLOW ----------------
    if status == "APPROVED":
        leave_type = event.get("leave_type")
        leave_days = event.get("leave_days", "N/A")

        remaining_days = 0

        if employee_id and leave_type:
            try:
                response = balances_table.get_item(
                    Key={"employee_id": employee_id}
                )

                item = response.get("Item", {})
                remaining_days = item.get(leave_type, 0)

            except Exception as e:
                print("Error fetching balance:", str(e))

        body = f"""
Hello {employee_name},

Your leave request has been APPROVED.

Request ID: {request_id}
Leave Type: {leave_type}
Approved Days: {leave_days}
Remaining {leave_type} Leave: {remaining_days} days

Regards,
Smart Leave System
"""

    # ---------------- REJECTED FLOW ----------------
    elif status == "REJECTED":

        reason = event.get("reason", "No reason provided")
        leave_type = event.get("leave_type", "N/A")
        start_date = event.get("start_date", "N/A")
        end_date = event.get("end_date", "N/A")

        body = f"""
Hello {employee_name},

Your leave request has been REJECTED.

Request ID: {request_id}
Leave Type: {leave_type}
Dates: {start_date} to {end_date}

Reason: {reason}

Regards,
Smart Leave System
"""

    else:
        body = f"""
Hello {employee_name},

Your leave request status is: {status}

Request ID: {request_id}
"""

    # ---------------- SEND EMAIL ----------------
    ses.send_email(
        Source=FROM_EMAIL,
        Destination={"ToAddresses": [employee_email]},
        Message={
            "Subject": {"Data": subject},
            "Body": {"Text": {"Data": body}}
        }
    )

    return {
        "statusCode": 200,
        "message": "Notification sent"
    }