import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['LEAVE_REQUESTS_TABLE'])


def lambda_handler(event, context):

    print("EVENT RECEIVED:", json.dumps(event))

    employee_id = event.get("employee_id")
    request_id = event.get("request_id")

    if not employee_id or not request_id:
        raise Exception("Missing employee_id or request_id")

    res = table.get_item(
        Key={
            "employee_id": employee_id,
            "request_id": request_id
        }
    )

    if "Item" not in res:
        raise Exception("Request not found")

    item = res["Item"]

    status = item.get("status", "")

    return {
        "employee_id": employee_id,
        "request_id": request_id,

        # existing fields (unchanged)
        "employee_name": item.get("employee_name"),
        "leave_type": item.get("leave_type"),
        "start_date": item.get("start_date"),
        "end_date": item.get("end_date"),
        "leave_days": item.get("leave_days", 0),

        # 🔥 FIXED LOGIC (IMPORTANT)
        "manager_approved": status == "MANAGER_APPROVED" or status == "APPROVED",
        "hr_approved": status == "HR_APPROVED" or status == "APPROVED",

        "manager_rejected": status == "REJECTED",
        "hr_rejected": status == "REJECTED"
    }